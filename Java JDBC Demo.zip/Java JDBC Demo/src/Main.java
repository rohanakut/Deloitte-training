import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.driver.OracleDriver;

public class Main {

	public static void main(String[] args) {
		
//		Step 1 Load The Driver and Register
//		Step 2 Establish the Connection
		
		try {
			Driver d = new OracleDriver();
			DriverManager.registerDriver(d);
			
			String userName = "hr";
			String password="hr";
			String url = "jdbc:oracle:thin:@192.168.1.54:1521:xe";
			
			Connection conn = DriverManager.getConnection(url,userName,password);
			System.out.println("Connection to Oracle Done");
		
			Statement stmt = conn.createStatement();
			
			String query = "select employee_id, first_name,last_name from employees";
			
			ResultSet rs = stmt.executeQuery(query);
			
			while (rs.next()) {
				System.out.println("Id = "+rs.getInt("employee_id")+" Name = "+rs.getString("first_name")+" "+rs.getString("last_name"));
			}
			
			String query2 = "select employee_id, first_name,last_name from employees where employee_id=?";
			
			PreparedStatement pstmt = conn.prepareStatement(query2);
			
			pstmt.setInt(1, 100);
			
			ResultSet rs2 = pstmt.executeQuery();
			
			while (rs2.next()) {
				System.out.println("Id = "+rs2.getInt("employee_id")+" Name = "+rs2.getString("first_name")+" "+rs2.getString("last_name"));
			}
			
			
			String query3 = "update  employees SET employee_id=999 where first_name='Steven';";
			
//			PreparedStatement pstmt3 = conn.prepareStatement(query3);
//			
//			pstmt3.setString(1, "Steven");
//			
//			ResultSet rs3 = pstmt3.executeQuery();
			
			int rs3 = stmt.executeUpdate(query3);
			
			
//			String insertQuery = "insert into books(?,?,?,?)";
//			PreparedStatement pstmt2 = conn.prepareStatement(insertQuery);
//			pstmt2.setInt(1,5);
//			pstmt2.setString(2,"old Man");
//			pstmt2.setString(3,"Ernest H");
//			pstmt2.setDate(4, java.sql.Date.valueOf("2013-09-04"));
//			
//			int rows=pstmt2.executeUpdate();
//			
//			System.out.println("No of rows inserted "+rows);
			
//			CallableStatement cstmt = conn.prepareCall("");
			
			conn.close();
			System.out.println("Closing the connection");
			
		} catch (SQLException e) {
			System.err.println("Error while registering the driver");
			e.printStackTrace();
		}
		
	}

}


