import java.sql.Connection;
import java.sql.Date;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import oracle.jdbc.driver.OracleDriver;

public class Main {

	class OrderItems{
		int order_id;
		int qty;
		
		public OrderItems(int order_id, int qty) {
			this.order_id = order_id;
			this.qty = qty;
		}
		
		
	}
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		Driver d = new OracleDriver();
		DriverManager.registerDriver(d);
		
		String userName = "hr";
		String password="hr";
		String url = "jdbc:oracle:thin:@192.168.1.54:1521:xe";
		
		Connection conn = DriverManager.getConnection(url,userName,password);
		conn.setAutoCommit(false);
		
		List<OrderItems> orderItems = new ArrayList<>();
		
		

		try {
			
			
			System.out.println("Connection to Oracle Done");
			
			String query = "insert into orders values(?,?,?)";
			
			PreparedStatement pstmt = conn.prepareStatement(query);
			
			pstmt.setInt(1,1);
			pstmt.setInt(2, 321);
			pstmt.setInt(3, 100);
			
			
			String queryItem = "insert into order_item values(?,?)";
			
			PreparedStatement pstmtItem = conn.prepareStatement(queryItem);
			
			pstmtItem.setInt(1, 1);
			pstmtItem.setDate(2, new Date(new java.util.Date().getTime()));
			
			int result = pstmt.executeUpdate();
			
			System.out.println("No. of Rows Executed "+result );
		
			
			
			if(result>0) {
				result = pstmtItem.executeUpdate();
				System.out.println("Oreder Item Inserted "+ result);
//				if (result>0) {
//					throw new SQLException("Error Occured while insertng rows for order");
//				}
			}
			
			orderItems.add
			
			conn.commit();
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error in DB handling");
			conn.rollback();
			conn.close();
			
			
		}finally {
			
		}
	}

}
