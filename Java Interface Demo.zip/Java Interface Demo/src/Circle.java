
public class Circle implements Shape {

	@Override
	public void area() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void info() {
		System.out.println("Optional Method want to overide and implement you can ");
	}

}
