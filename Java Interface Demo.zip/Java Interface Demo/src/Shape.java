import java.io.Serializable;

public interface Shape extends Serializable {
	void area();
	void draw();
	
	default void info() {
		System.out.println(" Only one default function with Defination Allowed");
	}
}
