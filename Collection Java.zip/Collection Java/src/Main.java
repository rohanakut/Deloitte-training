//import java.util.ArrayList;
//import java.util.Iterator;
//import java.util.List;
//
//public class Main {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//		List<String> artist = new ArrayList<>();
//		artist.add("A R Rehman");
//		artist.add("Pritams");
//		artist.add(0, "Vishal Shekhar"); //Add with index 
//		
//		System.out.println("Artists.....");
//		System.out.println(artist);
//		
//		artist.remove(0);
//		
//		
//		System.out.println(artist.contains("A R Rehman"));
//		
//		Iterator<String> itr = artist.iterator();
//		while (itr.hasNext()) {
//			String singers = (String) itr.next();
//			System.out.println(singers);
//		}
//		
//		
////		
//	}
//
//}


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		DataManager manager = new DataManager();
		
		manager.add(new Teacher(2, "Prem", "prem@gmail.com"));
		manager.add(new Teacher(4, "Anjali", "anjali@gmail.com"));
		manager.add(new Teacher(3, "Ratna", "ratna@gmail.com"));
		manager.add(new Teacher(1, "Ashish", "ashish@gmail.com"));
				
		System.out.println("Before sorting...");
		manager.print();
		
		System.out.println("After default sort...");
		manager.defaultSort();
		manager.print();
		
		System.out.println("After name sort...");
		manager.nameSort();
		manager.print();
		
		System.out.println("Element after email sort");
		manager.emailSort();
		manager.print();
		
		/*
		 * // List<String> artists = new ArrayList<>(); // List<String> goldenArtists =
		 * new ArrayList<>(); // // goldenArtists.add("R D Burman"); //
		 * goldenArtists.add("Lakshmikant Pyarelal"); //
		 * goldenArtists.add("Bappi Lahri"); // // artists.add("A R Rahman"); //
		 * artists.add("Pritam"); // artists.add(0, "Vishal Shekhar"); // // for(String
		 * artist : artists) { // System.out.println(artist.toUpperCase()); // } // //
		 * Iterator<String> itr = artists.iterator(); // while(itr.hasNext()) { //
		 * String artist = itr.next(); // System.out.println(artist.toLowerCase()); // }
		 */	
		
		System.out.println("Enter No of Students");
		Scanner sc = new Scanner(System.in);
		int nos = sc.nextInt();
		int id;
		String name, email;
		for (int i = 0; i < nos; i++) {
			
			System.out.println("Enter Name for Student"+(i+1));
			name = sc.next();
			System.out.println("Enter Email for Student"+(i+1));
			email = sc.next();
		
			manager.add(new Student(name, email));
			
		}
		
		System.out.println("Enter the choice for sort 1. Name 2. Email  3.id  4 Default");
		int choice = sc.nextInt();
		
		switch (choice) {
		case 1:
			System.out.println("After name sort...");
			manager.nameSortStudent();
			manager.printStudent();
			break;
		case 2:
			System.out.println("After Email sort...");
			manager.emailSortStudent();
			manager.printStudent();
			break;

		default:
			break;
		}
		
	}

}

