
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class DataManager {
	
	private List<Teacher> teachers;
	
	private List<Student> students;
	
	public DataManager() {
		teachers = new ArrayList<>();
		students = new ArrayList<>();
	}
	
	public void add(Teacher t) {
		teachers.add(t);
	}
	

	public void add(Student s) {
		students.add(s);
	}
	
	public void print() {
		for (Teacher t : teachers) {
			System.out.println(t);
		}
	}
	
	public void printStudent() {
		for (Student s : students) {
			System.out.println(s);
		}
	}
	
	public void defaultSort() {
		Collections.sort(teachers);
	}
	
	public void defaultSortStudent() {
		Collections.sort(students);
	}
	
	public void nameSort() {
		Collections.sort(teachers, new NameSort());
	}
	
	public void nameSortStudent() {
		Collections.sort(students, new NameSortStudent());
	}
	
	public void emailSort() {
		Collections.sort(teachers,new EmailSort());
	}


	public void emailSortStudent() {
		Collections.sort(students,new EmailSortStudent());
	}
	

	class NameSort implements Comparator<Teacher>{

		@Override
		public int compare(Teacher o1, Teacher o2) {
			return o1.getName().compareTo(o2.getName());
		}
		
	}

	class NameSortStudent implements Comparator<Student>{

		@Override
		public int compare(Student o1, Student o2) {
			return o1.getName().compareTo(o2.getName());
		}
		
	}

	class EmailSort implements Comparator<Teacher>{

		@Override
		public int compare(Teacher o1, Teacher o2) {
			// TODO Auto-generated method stub
			return o1.getEmail().compareTo(o2.getEmail());
			}
		
	}

	class EmailSortStudent implements Comparator<Student>{

		@Override
		public int compare(Student o1, Student o2) {
			// TODO Auto-generated method stub
			return o1.getEmail().compareTo(o2.getEmail());
			}			
	}

}