create table Patient(Patient_Id number UNIQUE,
                    Patient_Name varchar2(20) NOT NULL,
                    Patient_Email varchar2(20) UNIQUE,
                    Patient_Registered_Date date   default SYSDATE);
                    
desc Patient;

ALTER TABLE Patient
ADD PRIMARY KEY (Patient_Id); 

create table Medicine(Medicine_Id number PRIMARY KEY,
                      Medicine_Name varchar2(20) NOT NULL  );

create table Prescription(Prescription_Id number UNIQUE,
                          Prescribed_Date date default SYSDATE,
                          Patient_Id number,
                          CONSTRAINT FK_Patient_Id FOREIGN KEY (Patient_Id) REFERENCES Patient(Patient_Id));  
                          
desc Prescription;

create table Store(Id number PRIMARY KEY,
                   Prescription_Id number,
                   Medicine_Id number,
                    CONSTRAINT FK_Prescription_Id FOREIGN KEY (Prescription_Id) REFERENCES Prescription(Prescription_Id),
                    CONSTRAINT FK_Medicine_Id FOREIGN KEY (Medicine_Id) REFERENCES Medicine(Medicine_Id));
                    
insert into patient values(1,'Ajay','a@a.com',sysdate);
insert into patient values(2,'Bay','b@a.com',sysdate);
insert into patient values(3,'Chand','c@a.com',sysdate);

insert into medicine VALUES(10,'Crocin');
insert into medicine VALUES(20,'Nice');
insert into medicine VALUES(30,'Acidity');
insert into medicine VALUES(40,'Band Aid');
insert into medicine VALUES(50,'Dettol');


INSERT INTO prescription VALUES(100,sysdate,1);
INSERT INTO prescription VALUES(200,sysdate,2);
INSERT INTO prescription VALUES(300,sysdate,3);


insert into Store values(1,100,10);
insert into Store values(2,200,20);
insert into Store values(3,300,30);

Select * from patient;
select * from prescription;
select * from Store;
select * from Medicine;

select * from patient where patient_registered_date between '27-DEC-2019' AND '29-DEC-2019';

select p.Patient_Name, pr.Prescription_Id,s.medicine_id,m.medicine_name  from Patient p, prescription pr,Store s, Medicine m 
where p.patient_id=pr.patient_id and pr.prescription_Id = s.prescription_id and s.medicine_id = m.medicine_id; 
                    
