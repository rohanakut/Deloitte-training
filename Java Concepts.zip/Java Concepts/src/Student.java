public class Student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		add(1,2,3,4);
		add(9,8,7,6);
	}

	public static void add(int ...arr) {
		int sum =0;
		for(int a:arr) {
			sum+=a;
		}
		System.out.println("Sum = "+sum);
	}
}
