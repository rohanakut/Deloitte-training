import java.util.Arrays;

public class Employee {
	
	int id,sal;
	String name;
	
	public Employee(int id, int sal, String name) {
		
		this.id = id;
		this.sal = sal;
		this.name = name;
	}

	
	
	
	public static void main(String[] args) {
		Employee[] e = new Employee[3];
		e[0]=new Employee(1,1000,"Chinmay");
		e[1]=new Employee(1,1000,"Bhinmay");
		e[2]=new Employee(1,1000,"Rhinmay");
//		
//		for(Employee s:e) {
//	         
//	            if(s.compareTo(myArray[j])>0) {
//	               String temp = myArray[i];
//	               myArray[i] = myArray[j];
//	               myArray[j] = temp;
//	            }
//	         }
	}

}
