import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

class User implements Serializable{
	
	public User(String name, String email) {
		this.name = name;
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	private String name;
	private String email;
}



public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Main m = new Main();
//		m.writeData();
//		m.writeDataAsChars();
//		m.readDataAsChar();
//		if(m.checkExistance()) {
//			System.out.println("Word Found");
//		}
		
		m.serialize();
	}
	
	
	void serialize() throws IOException {
		String fileName = "user.dat";
		
		User u = new User("Chinmay", "c@com");
		FileOutputStream fileOutputStream = new FileOutputStream(fileName);
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
		
		objectOutputStream.writeObject(u);
		
		fileOutputStream.close();
	}
	
	void deSerialize() throws FileNotFoundException, IOException, ClassNotFoundException {
		String fileName="user.dat";
		User u = null;
		try(FileInputStream fIn = new FileInputStream(fileName)){
			ObjectInputStream objIn = new ObjectInputStream(fIn);
			u = (User)objIn.readObject();
			System.out.println(u);
		}
	}
	
	boolean checkExistance() throws IOException {
		
//		System.out.println("");
		String fileName ="D:\\javaio.txt";
		String data = "";
		int count=0;
		try(BufferedReader reader = new BufferedReader(new FileReader(fileName))){
			String repWord="";
			Scanner sc = new Scanner(System.in);
			data = reader.readLine();
		
			while (data!=null) {
		
				String[] words=data.split(" ");  //Split the word using space
		          for (String word : words) 
		          {
		                 if (word.equals("desktop"))   //Search for the given word
		                 {
		                   count++;    //If Present increase the count by one
		                   
		                   System.out.println("Enter the Word to be Replaced?");
		                   repWord = sc.next();
		                   String fileNameW ="D:\\javaio.txt";
		           		try(FileWriter writer = new FileWriter(fileNameW,true)){
		           			writer.write(repWord.toCharArray());
		           		}
		                   
		                   
//		                   return true;
		                 }
		                 
		                 else {
		                	 String fileNameW ="D:\\javaio.txt";
				           		try(FileWriter writer = new FileWriter(fileNameW,true)){
				           			writer.write(word.toCharArray());
				           		}
		                 }
		          }
//				if(data.equals("Lorem"))
//					return true;
		          
				data = reader.readLine();
			}
			
			
//			while((reader.readLine())!=null)   //Reading Content from the file
//		      {
//		         words=s.split(" ");  //Split the word using space
//		          for (String word : words) 
//		          {
//		                 if (word.equals(input))   //Search for the given word
//		                 {
//		                   count++;    //If Present increase the count by one
//		                 }
//		          }
//		      }
			
			return false;
		}
		
		
		
	}
	void writeData() throws IOException {
		String fileName ="D:\\javaio.txt";
		
		FileOutputStream stream = new FileOutputStream(fileName,true);
		stream.write("Java".getBytes());
		stream.flush();
		stream.close();
	}
	
	void writeDataAsChars() throws IOException {
		String fileName ="D:\\javaio.txt";
		try(FileWriter writer = new FileWriter(fileName,true)){
			writer.write("Writing from Chars Writer Functions".toCharArray());
		}
	}
	
	void readDataAsChar() throws FileNotFoundException, IOException {
		String fileName ="D:\\javaio.txt";
		String data = "";
		try(BufferedReader reader = new BufferedReader(new FileReader(fileName))){
			data = reader.readLine();
			while (data!=null) {
				System.out.println(data);
				data = reader.readLine();
			}
		}
	}
	
	void readDataAsBytes()throws IOException{
		String fileName = "D:\\javaio.txt";
		FileInputStream inStream = new FileInputStream(fileName);
		int data = inStream.read();
		while (data!=-1) {
			System.out.println((char)data);
			data=inStream.read();
		}
		inStream.close();
	}
	

	void readDataAsBytesTryResources()throws IOException{
		String fileName = "D:\\javaio.txt";
		try(FileInputStream inStream = new FileInputStream(fileName)){
		int data = inStream.read();
		while (data!=-1) {
			System.out.println((char)data);
			data=inStream.read();
			}
		}
	}

}
