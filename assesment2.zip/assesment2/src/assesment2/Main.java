package assesment2;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.time.LocalDateTime;

import oracle.jdbc.driver.OracleDriver;

public class Main {
	
	Driver d = null;
	Connection conn = null;
	
	public void connect() {
		
		try {
			d = new OracleDriver();
			DriverManager.registerDriver(d);
			
			String uername = "hr";
			String password = "hr";
			String url = "jdbc:oracle:thin:@192.168.1.57:1522:xe";
			
			conn = DriverManager.getConnection(url, uername, password);
			//conn.setAutoCommit(false);
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("Connection to oracle database opens....");
	}
	
	public void insert(int id, String name, String email) {
		String query = "insert into patient_details values (?,?,?,?)";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(query);
			
			stmt.setInt(1, id);
			stmt.setString(2, name);
			stmt.setString(3, email);
			stmt.setDate(4, java.sql.Date.valueOf(java.time.LocalDate.now()));
			
			int r = stmt.executeUpdate();
			System.out.println(r + " row inserted in patients");
		} catch (SQLException e) {
			System.out.println("Error in insertind data in table !");
			e.printStackTrace();
		}
	}
	
	public void insert_prescription(int id, int prescription_pid, String name) {
		String query = "insert into prescription_details values (?,?,?,?)";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(query);
			
			stmt.setInt(1, id);
			stmt.setDate(2, java.sql.Date.valueOf(java.time.LocalDate.now()));
			stmt.setInt(3, prescription_pid);
			stmt.setString(4, name);
			
			int r = stmt.executeUpdate();
			System.out.println(r + " row inserted in patients");
		} catch (SQLException e) {
			System.out.println("Error in insertind data in table !");
			e.printStackTrace();
		}
	}
	
	public void update(int id,String str, String str1) {
		String query = "update patient_details set patietnt_email = (?),patient_name = (?) where patient_id = (?)";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(query);
			
			stmt.setString(1, str);
			stmt.setString(2, str1);
			stmt.setInt(3, id);
			
			int r = stmt.executeUpdate();
			System.out.println(r + " row updated!");
		} 
		catch (SQLException e) {
			System.out.println("Error in updating!!!");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void display() {
		String query = "select * from patient_details";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(query);
			
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				System.out.print("ID := "+rs.getInt("patient_id"));
				System.out.println("  Name := "+ rs.getString("patient_name")+" "+rs.getString("patietnt_email")+" "+rs.getDate("patient_registered_date"));
				
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void delete(int id) {
		String query = "delete from prescription_details where prescription_id = (?)";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(query);
			
			stmt.setInt(1, id);
			
			int r = stmt.executeUpdate();
			System.out.println(r+" row deleted!");
		} 
		catch (SQLException e) {
			System.out.println("Error in deleting!");
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		
		Main m = new Main();
		m.connect();
		
		Scanner sc = new Scanner(System.in);
		
		
		
		while (true) {
			
			System.out.println("1. Add patient_details,2.Add presciption Details 3.Display, 4.Update name & email, 5.Delete prescriptions ,6.Exit");
			System.out.println("Enter ur choice: ");
			int n = sc.nextInt();
			
			switch (n) {
			case 1:
				
				System.out.println("Enter id  ");
				int id = sc.nextInt();
				
				System.out.println("Enter name  ");
				String nm = sc.next();

				System.out.println("Enter email ");
				String em = sc.next();
				
				//Students stud = new Students(nm, em);
				//System.out.println(stud);
				
				m.insert(id,nm,em);
				

				break;
			case 2:	
				System.out.println("Enter prescription id  ");
				int prescription_id = sc.nextInt();
				
				System.out.println("Enter patient id  ");
				int prescription_pid = sc.nextInt();

				System.out.println("Enter medicine name ");
				String prescription_mn = sc.next();
				
				//Students stud = new Students(nm, em);
				//System.out.println(stud);
				
				m.insert_prescription(prescription_id,prescription_pid,prescription_mn);
				

				break;

			case 3:
				m.display();
				
				break;
			case 4:
				System.out.println("enter id whose name is to be updated: ");
				int id1 = sc.nextInt();
				System.out.println("enter name to be updated: ");
				String nm_up = sc.next();
				System.out.println("enter email to be updated: ");
				String em_up = sc.next();
				
				m.update(id1, em_up,nm_up);
				
				break;
			case 5:
				System.out.println("Enter the prescription_id to be deleted:");
				int id2 = sc.nextInt();
				
				m.delete(id2);
				break;
			case 6:
				sc.close();
				System.exit(0);

			default:
				break;
			}
		}

	}

}